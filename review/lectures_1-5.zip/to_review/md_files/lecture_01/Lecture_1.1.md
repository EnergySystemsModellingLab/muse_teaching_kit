---
title: Mini-Lecture 1.1 - Introduction to the course
keywords:
-   Energy systems modelling
-   Agent-based models
-   Climate adaptation
authors:
-   Alexander Kell
---

# Short description

This mini-lecture will provide an overview of how the course is structured. The course is structured into 

# Learning objectives

-   To present the structure of the course for both the lecture content
    and the hands-on sessions
-   To obtain an introductory insight into the content delivered within
    this course.

# Introduction and structure of the course



# Concluding remarks


